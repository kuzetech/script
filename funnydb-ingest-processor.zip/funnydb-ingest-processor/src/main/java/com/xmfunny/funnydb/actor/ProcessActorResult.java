package com.xmfunny.funnydb.actor;

import com.xmfunny.funnydb.kafka.IngestRecord;

public class ProcessActorResult {

    private Boolean result;
    private String msg;
    private IngestRecord record;
    private String key;
    private String topic;

    public ProcessActorResult() {
    }

    public ProcessActorResult(Boolean result, String msg, IngestRecord record) {
        this.result = result;
        this.msg = msg;
        this.record = record;
    }

    public ProcessActorResult(Boolean result, String msg, IngestRecord record, String key, String topic) {
        this.result = result;
        this.msg = msg;
        this.record = record;
        this.key = key;
        this.topic = topic;
    }

    public static ProcessActorResult createSuccessResult(IngestRecord record) {
        return new ProcessActorResult(true, "", record);
    }

    public static ProcessActorResult createSuccessKafkaResult(IngestRecord record, String key, String topic) {
        return new ProcessActorResult(true, "", record, key, topic);
    }

    public static ProcessActorResult createFairResult(String msg, IngestRecord record) {
        return new ProcessActorResult(false, msg, record);
    }

    public Boolean getResult() {
        return result;
    }

    public void setResult(Boolean result) {
        this.result = result;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public IngestRecord getRecord() {
        return record;
    }

    public void setRecord(IngestRecord record) {
        this.record = record;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }
}
