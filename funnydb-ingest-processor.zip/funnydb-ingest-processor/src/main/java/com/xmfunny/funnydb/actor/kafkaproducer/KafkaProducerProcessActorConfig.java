package com.xmfunny.funnydb.actor.kafkaproducer;

import com.fasterxml.jackson.annotation.JsonProperty;

public class KafkaProducerProcessActorConfig {

    private String format;
    private String topic;
    private String key;

    @JsonProperty("only_data")
    private boolean onlyData;
    @JsonProperty("key_fields")
    private String[] keyFields;

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public boolean isOnlyData() {
        return onlyData;
    }

    public void setOnlyData(boolean onlyData) {
        this.onlyData = onlyData;
    }

    public String[] getKeyFields() {
        return keyFields;
    }

    public void setKeyFields(String[] keyFields) {
        this.keyFields = keyFields;
    }
}
