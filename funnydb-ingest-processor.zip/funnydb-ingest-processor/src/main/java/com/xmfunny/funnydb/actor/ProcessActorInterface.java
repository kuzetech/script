package com.xmfunny.funnydb.actor;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.xmfunny.funnydb.MetadataEvaluator;
import com.xmfunny.funnydb.actor.clientipinjector.ClientIpInjectorProcessActor;
import com.xmfunny.funnydb.actor.geoip.GeoIPProcessActor;
import com.xmfunny.funnydb.actor.kafkaproducer.KafkaProducerProcessActor;
import com.xmfunny.funnydb.actor.lifecycle.LifeCycleInjectProcessActor;
import com.xmfunny.funnydb.actor.messagemodifier.MessageModifierProcessActor;
import com.xmfunny.funnydb.actor.validatorv2.EventValidatorV2ProcessActor;
import com.xmfunny.funnydb.actor.validatorv2.SchemaValidatorV2ProcessActor;
import com.xmfunny.funnydb.kafka.IngestRecord;
import com.xmfunny.funnydb.metadata.Processors;

import java.io.IOException;

public interface ProcessActorInterface {

    ProcessActorResult process(IngestRecord data);

    static ObjectMapper mapper = new ObjectMapper();

    static ProcessActorInterface generateFromConfig(Processors processors, MetadataEvaluator evaluator) throws IOException {
        switch (processors.getType()) {
            case Processors.PROCESSOR_TYPE_CLIENT_IP_INJECTOR:
                return ClientIpInjectorProcessActor.generateFromProcessor(processors, evaluator);
            case Processors.PROCESSOR_TYPE_LIFECYCLE_INJECTOR:
                return LifeCycleInjectProcessActor.generateFromProcessor(processors, evaluator);
            case Processors.PROCESSOR_TYPE_GEOIP:
                return GeoIPProcessActor.generateFromProcessor(processors, evaluator);
            case Processors.PROCESSOR_TYPE_MESSAGE_MODIFIER:
                return MessageModifierProcessActor.generateFromProcessor(processors, evaluator);
            case Processors.PROCESSOR_TYPE_SCHEMA_VALIDATOR_V2:
                return SchemaValidatorV2ProcessActor.generateFromProcessor(processors, evaluator);
            case Processors.PROCESSOR_TYPE_EVENT_VALIDATOR_V2:
                return EventValidatorV2ProcessActor.generateFromProcessor(processors, evaluator);
            case Processors.PROCESSOR_TYPE_KAFKA_PRODUCER:
                return KafkaProducerProcessActor.generateFromProcessor(processors, evaluator);
            default:
                if (processors.getProcessors() != null && processors.getProcessors().length > 0) {
                    return generateFromConfig(processors.getProcessors()[0], evaluator);
                }
                return null;
        }
    }
}
