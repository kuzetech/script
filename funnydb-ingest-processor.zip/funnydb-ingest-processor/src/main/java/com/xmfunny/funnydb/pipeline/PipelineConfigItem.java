package com.xmfunny.funnydb.pipeline;

import com.xmfunny.funnydb.metadata.Processors;

import java.util.Map;

public class PipelineConfigItem {
    private Map<String, Processors> typeMap;

    public Map<String, Processors> getTypeMap() {
        return typeMap;
    }

    public void setTypeMap(Map<String, Processors> typeMap) {
        this.typeMap = typeMap;
    }
}
