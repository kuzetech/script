package com.xmfunny.funnydb.actor.messagemodifier;

public class SetProperty {
    private String name;
    // 原场景中支持注入任意类型，当前仅先支持 string
    private String value;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
