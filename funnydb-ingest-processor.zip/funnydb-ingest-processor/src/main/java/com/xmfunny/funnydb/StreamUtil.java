package com.xmfunny.funnydb;

import org.apache.flink.api.common.restartstrategy.RestartStrategies;
import org.apache.flink.api.common.time.Time;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.streaming.api.CheckpointingMode;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.jetbrains.annotations.NotNull;

public class StreamUtil {

    @NotNull
    public static StreamExecutionEnvironment prepareExecutionEnv(ParameterTool parameterTool) {

        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.setRestartStrategy(RestartStrategies.fixedDelayRestart(3, Time.seconds(10)));
        env.enableCheckpointing(5000, CheckpointingMode.EXACTLY_ONCE);

        env.setParallelism(2);
        // env.setStateBackend(new EmbeddedRocksDBStateBackend(true));
        // env.getCheckpointConfig().setCheckpointStorage("file:///funnydb-ingest-processor/checkpoints");

        env.getConfig().setGlobalJobParameters(parameterTool);

        return env;
    }

}
