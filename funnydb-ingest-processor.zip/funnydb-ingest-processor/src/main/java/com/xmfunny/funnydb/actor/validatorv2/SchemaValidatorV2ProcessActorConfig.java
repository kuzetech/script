package com.xmfunny.funnydb.actor.validatorv2;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties({"validate_log", "validate_stats"})
public class SchemaValidatorV2ProcessActorConfig {

    @JsonProperty("keep_unknown_fields")
    private boolean keepUnknownFields;
    private TypeDecl schema;

    public boolean isKeepUnknownFields() {
        return keepUnknownFields;
    }

    public void setKeepUnknownFields(boolean keepUnknownFields) {
        this.keepUnknownFields = keepUnknownFields;
    }

    public TypeDecl getSchema() {
        return schema;
    }

    public void setSchema(TypeDecl schema) {
        this.schema = schema;
    }
}
