package com.xmfunny.funnydb.kafka;

import org.apache.flink.api.common.serialization.SerializationSchema;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.connector.kafka.sink.KafkaRecordSerializationSchema;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.jetbrains.annotations.Nullable;

import java.nio.charset.StandardCharsets;

public class KafkaRecordDispatcherSerializationSchema
        implements KafkaRecordSerializationSchema<Tuple2<DispatcherInfo, String>> {

    @Override
    public void open(SerializationSchema.InitializationContext context, KafkaSinkContext sinkContext) throws Exception {
        KafkaRecordSerializationSchema.super.open(context, sinkContext);
    }

    @Nullable
    @Override
    public ProducerRecord<byte[], byte[]> serialize(Tuple2<DispatcherInfo, String> data, KafkaSinkContext context, Long timestamp) {
        DispatcherInfo info = data.f0;


        if (info.getSuccess()) {
            return new ProducerRecord<>(
                    info.getTopic(),
                    info.getKey() == null ? null : info.getKey().getBytes(StandardCharsets.UTF_8),
                    data.f1.getBytes(StandardCharsets.UTF_8));
        } else {
            return new ProducerRecord<>(
                    info.getTopic(),
                    data.f1.getBytes(StandardCharsets.UTF_8));
        }


    }
}
