package com.xmfunny.funnydb.actor.validatorv2;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.xmfunny.funnydb.metadata.Processors;

public class EventConfig {
    @JsonProperty("keep_unknown_fields")
    private boolean keepUnknownFields;
    private TypeDecl schema;
    private Processors[] processors;

    public boolean isKeepUnknownFields() {
        return keepUnknownFields;
    }

    public void setKeepUnknownFields(boolean keepUnknownFields) {
        this.keepUnknownFields = keepUnknownFields;
    }

    public TypeDecl getSchema() {
        return schema;
    }

    public void setSchema(TypeDecl schema) {
        this.schema = schema;
    }

    public Processors[] getProcessors() {
        return processors;
    }

    public void setProcessors(Processors[] processors) {
        this.processors = processors;
    }
}
