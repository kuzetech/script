package com.xmfunny.funnydb.actor.lifecycle;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties({"validate_stats", "failed_processors"})
public class LifeCycleInjectProcessActorConfig {

    @JsonProperty("time_field_name")
    private String timeFieldName;
    @JsonProperty("inject_field_name")
    private String injectFieldName;
    @JsonProperty("life_cycles")
    private LifeCycle[] lifeCycles;

    public String getTimeFieldName() {
        return timeFieldName;
    }

    public void setTimeFieldName(String timeFieldName) {
        this.timeFieldName = timeFieldName;
    }

    public String getInjectFieldName() {
        return injectFieldName;
    }

    public void setInjectFieldName(String injectFieldName) {
        this.injectFieldName = injectFieldName;
    }

    public LifeCycle[] getLifeCycles() {
        return lifeCycles;
    }

    public void setLifeCycles(LifeCycle[] lifeCycles) {
        this.lifeCycles = lifeCycles;
    }
}
