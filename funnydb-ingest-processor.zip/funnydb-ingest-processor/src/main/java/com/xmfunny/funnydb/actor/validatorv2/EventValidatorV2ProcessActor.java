package com.xmfunny.funnydb.actor.validatorv2;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.xmfunny.funnydb.MetadataEvaluator;
import com.xmfunny.funnydb.actor.ProcessActorInterface;
import com.xmfunny.funnydb.actor.ProcessActorResult;
import com.xmfunny.funnydb.kafka.IngestRecord;
import com.xmfunny.funnydb.metadata.Processors;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;

public class EventValidatorV2ProcessActor implements ProcessActorInterface {

    private EventValidatorV2ProcessActorConfig config;

    private final Map<String, Function<Object, Object>> projectors = new HashMap<>();
    private final Map<String, ProcessActorInterface> eventRouterMap = new HashMap<>();

    public static EventValidatorV2ProcessActor generateFromProcessor(Processors processor, MetadataEvaluator evaluator) throws IOException {
        EventValidatorV2ProcessActorConfig config =
                ProcessActorInterface.mapper.treeToValue(processor.getConfig(), EventValidatorV2ProcessActorConfig.class);

        EventValidatorV2ProcessActor actor = new EventValidatorV2ProcessActor();
        actor.config = config;

        Set<String> keySet = config.getEvents().keySet();
        for (String key : keySet) {
            EventConfig eventConfig = config.getEvents().get(key);
            actor.projectors.put(key, Projector.buildProjector(eventConfig.getSchema()));

            if (eventConfig.getProcessors() != null && eventConfig.getProcessors().length > 0) {
                actor.eventRouterMap.put(key, ProcessActorInterface.generateFromConfig(eventConfig.getProcessors()[0], evaluator));
            }
        }

        return actor;
    }

    @Override
    public ProcessActorResult process(IngestRecord record) {
        ObjectNode data = record.getData();

        JsonNode eventNode = data.get(config.getEventProperty());
        if (eventNode == null) {
            return ProcessActorResult.createFairResult(
                    "EventValidatorV2ProcessActor : miss event field : " + config.getEventProperty(),
                    record);
        }

        boolean isStringType = eventNode.isTextual();
        if (!isStringType) {
            return ProcessActorResult.createFairResult(
                    "EventValidatorV2ProcessActor : event field type error : " + config.getEventProperty(),
                    record);
        }

        String event = eventNode.asText();

        EventConfig eventConfig = config.getEvents().get(event);
        if (eventConfig == null) {
            return ProcessActorResult.createFairResult(
                    "EventValidatorV2ProcessActor : no suitable event : " + event, record);
        }

        ValidatorResult r = new ValidatorResult();
        Validator.validateData("", eventConfig.getSchema(), data, true, r);
        if (!r.getErrors().isEmpty()) {
            StringBuilder errorMsg = new StringBuilder();
            for (ValidatorDetailItem error : r.getErrors()) {
                errorMsg.append(error.getMessage()).append(";");
            }
            return ProcessActorResult.createFairResult(
                    "EventValidatorV2ProcessActor : valid error : " + errorMsg,
                    record);
        }

        for (int i = r.getDeletes().size() - 1; i >= 0; i--) {
            String deleteItem = r.getDeletes().get(i);
            Projector.deleteElementByPath(record.getData(), deleteItem);
        }

        if (!eventConfig.isKeepUnknownFields()) {
            data = (ObjectNode) projectors.get(event).apply(data);
        }

        ProcessActorInterface nextProcessorActor = eventRouterMap.get(event);

        record.setData(data);

        return nextProcessorActor.process(record);
    }

}
