package com.xmfunny.funnydb.metadata;

import com.fasterxml.jackson.annotation.JsonProperty;

public class MetadataSyncRequest {
    @JsonProperty("instance_id")
    private Integer instanceId;
    @JsonProperty("metadata_id")
    private Integer metadataID;
    private Integer timeout;

    public MetadataSyncRequest() {
    }

    public MetadataSyncRequest(Integer instanceId, Integer metadataID, Integer timeout) {
        this.instanceId = instanceId;
        this.metadataID = metadataID;
        this.timeout = timeout;
    }

    public Integer getInstanceId() {
        return instanceId;
    }

    public void setInstanceId(Integer instanceId) {
        this.instanceId = instanceId;
    }

    public Integer getMetadataID() {
        return metadataID;
    }

    public void setMetadataID(Integer metadataID) {
        this.metadataID = metadataID;
    }

    public Integer getTimeout() {
        return timeout;
    }

    public void setTimeout(Integer timeout) {
        this.timeout = timeout;
    }
}
