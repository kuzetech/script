package com.xmfunny.funnydb.actor.geoip;

import com.maxmind.geoip2.DatabaseReader;
import com.maxmind.geoip2.model.CityResponse;
import com.maxmind.geoip2.model.CountryResponse;
import com.maxmind.geoip2.model.IspResponse;

import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.util.Map;

public class GeoIPDB {

    private final DatabaseReader countryReader;
    private final DatabaseReader cityReader;
    private final DatabaseReader ispReader;

    public GeoIPDB(String dbDirPath) throws IOException {

        File countryFile = new File(dbDirPath + "/maxmind-geoip2-country.mmdb");
        countryReader = new DatabaseReader.Builder(countryFile).build();

        File cityFile = new File(dbDirPath + "/maxmind-geoip2-city.mmdb");
        cityReader = new DatabaseReader.Builder(cityFile).build();

        File ispFile = new File(dbDirPath + "/maxmind-geoip2-isp.mmdb");
        ispReader = new DatabaseReader.Builder(ispFile).build();
    }

    public ContinentInfo lookupContinent(String ip, String[] preferedLocales) throws Exception {
        InetAddress ipAddress = InetAddress.getByName(ip);
        CountryResponse response = this.countryReader.country(ipAddress);
        return ContinentInfo.generateFromGeoResponse(response, preferedLocales);
    }

    public CountryInfo lookupCountry(String ip, String[] preferedLocales) throws Exception {
        InetAddress ipAddress = InetAddress.getByName(ip);
        CountryResponse response = this.countryReader.country(ipAddress);
        return CountryInfo.generateFromGeoResponse(response, preferedLocales);
    }

    public CityInfo lookupCity(String ip, String[] preferedLocales) throws Exception {
        InetAddress ipAddress = InetAddress.getByName(ip);
        CityResponse response = this.cityReader.city(ipAddress);
        return CityInfo.generateFromGeoResponse(response, preferedLocales);
    }

    public SubdivisionInfo lookupSubdivisions(String ip, String[] preferedLocales) throws Exception {
        InetAddress ipAddress = InetAddress.getByName(ip);
        CityResponse response = this.cityReader.city(ipAddress);
        return SubdivisionInfo.generateFromGeoResponse(response, preferedLocales);
    }

    public IspInfo lookupIsp(String ip) throws Exception {
        InetAddress ipAddress = InetAddress.getByName(ip);
        IspResponse response = this.ispReader.isp(ipAddress);
        return IspInfo.generateFromGeoResponse(response);
    }

    public static String getLocalizedName(Map<String, String> names, String[] locales) {
        for (String local : locales) {
            String name = names.get(local);
            if (name != null) {
                return name;
            }
        }
        return "";
    }

    public void close() throws IOException {
        this.countryReader.close();
        this.cityReader.close();
        this.ispReader.close();
    }
}
