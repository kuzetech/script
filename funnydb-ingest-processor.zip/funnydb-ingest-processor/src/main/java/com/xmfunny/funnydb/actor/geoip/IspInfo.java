package com.xmfunny.funnydb.actor.geoip;

import com.maxmind.geoip2.model.IspResponse;

public class IspInfo {
    private String name;

    public static IspInfo generateFromGeoResponse(IspResponse response) {
        IspInfo info = new IspInfo();
        info.setName(response.getIsp());
        return info;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
