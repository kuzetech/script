package com.xmfunny.funnydb.actor.validatorv2;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeType;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class Validator {

    public static void validateData(String level, TypeDecl typeDecl, JsonNode data, Boolean exist, ValidatorResult r) {
        String expectType = typeDecl.getType();
        boolean required = typeDecl.isRequired();
        if (!exist) {
            ValidatorDetailItem item = new ValidatorDetailItem(level, level + " 未上报");
            if (required) {
                item.setCode(ValidatorDetailItem.CODE_REQUIRED_PROPERTY_MISS_ERR);
                r.getErrors().add(item);
            } else {
                if (!typeDecl.isIgnoreMiss()) {
                    item.setCode(ValidatorDetailItem.CODE_OPTIONAL_PROPERTY_MISS_ERR);
                    r.getDeleteItems().add(item);
                }
            }
        } else {
            if (data == null) {
                ValidatorDetailItem item = new ValidatorDetailItem(level, level + " 上报的内容为空");
                if (required) {
                    item.setCode(ValidatorDetailItem.CODE_REQUIRED_PROPERTY_NIL_ERR);
                    r.getErrors().add(item);
                } else {
                    item.setCode(ValidatorDetailItem.CODE_OPTIONAL_PROPERTY_NIL_ERR);
                    r.getDeletes().add(level);
                    r.getDeleteItems().add(item);
                }
            } else {
                switch (expectType) {
                    case "object":
                        boolean dataIsObjectType = data.getNodeType().equals(JsonNodeType.OBJECT);
                        if (!dataIsObjectType) {
                            ValidatorDetailItem item = new ValidatorDetailItem(
                                    level,
                                    level + " 必须是 object 类型",
                                    "object",
                                    getDataType(data));
                            if (required) {
                                item.setCode(ValidatorDetailItem.CODE_REQUIRED_PROPERTY_TYPE_ERR);
                                r.getErrors().add(item);
                            } else {
                                item.setCode(ValidatorDetailItem.CODE_OPTIONAL_PROPERTY_TYPE_ERR);
                                r.getDeletes().add(level);
                                r.getDeleteItems().add(item);
                            }
                        } else {
                            Map<String, Boolean> schemaFieldNameMap = new HashMap<>();
                            for (TypeDecl fieldObj : typeDecl.getFields()) {
                                schemaFieldNameMap.put(fieldObj.getName(), true);
                                JsonNode value = data.get(fieldObj.getName());
                                Boolean e = value != null;
                                validateData(level + "/" + fieldObj.getName(), fieldObj, value, e, r);
                            }
                            Iterator<String> fieldNames = data.fieldNames();
                            while (fieldNames.hasNext()) {
                                String f = fieldNames.next();
                                if (schemaFieldNameMap.get(f) == null) {
                                    String additionalLevel = level + "/" + f;
                                    r.getDeleteItems().add(
                                            new ValidatorDetailItem(
                                                    ValidatorDetailItem.CODE_ADDITIONAL_PROPERTY_ERR,
                                                    additionalLevel,
                                                    additionalLevel + " 是多余上传的字段"));
                                }
                            }
                        }
                        break;
                    case "array":
                        boolean dataIsArrayType = data.getNodeType().equals(JsonNodeType.ARRAY);
                        if (!dataIsArrayType) {
                            ValidatorDetailItem item = new ValidatorDetailItem(
                                    level,
                                    level + " 必须是 array 类型",
                                    "array",
                                    getDataType(data));
                            if (required) {
                                item.setCode(ValidatorDetailItem.CODE_REQUIRED_PROPERTY_TYPE_ERR);
                                r.getErrors().add(item);
                            } else {
                                item.setCode(ValidatorDetailItem.CODE_OPTIONAL_PROPERTY_TYPE_ERR);
                                r.getDeletes().add(level);
                                r.getDeleteItems().add(item);
                            }
                        } else {
                            ArrayNode arrayNode = (ArrayNode) data;
                            Iterator<JsonNode> elements = arrayNode.elements();
                            int index = 0;
                            while (elements.hasNext()) {
                                JsonNode value = elements.next();
                                validateData(level + "/[" + index + "]", typeDecl.getItems(), value, true, r);
                                index = index + 1;
                            }
                        }
                        break;
                    default:
                        String dataType = getDataType(data);
                        String errorMsg = compareDataType(dataType, expectType);
                        if (!errorMsg.isEmpty()) {
                            ValidatorDetailItem item = new ValidatorDetailItem(
                                    level,
                                    level + " 类型错误，" + errorMsg,
                                    expectType,
                                    dataType);
                            if (required) {
                                item.setCode(ValidatorDetailItem.CODE_REQUIRED_PROPERTY_TYPE_ERR);
                                r.getErrors().add(item);
                            } else {
                                item.setCode(ValidatorDetailItem.CODE_OPTIONAL_PROPERTY_TYPE_ERR);
                                r.getDeletes().add(level);
                                r.getDeleteItems().add(item);
                            }
                        }
                }
            }
        }
    }

    private static String getDataType(JsonNode data) {
        JsonNodeType nodeType = data.getNodeType();
        switch (nodeType) {
            case OBJECT:
                return "object";
            case ARRAY:
                return "array";
            case BOOLEAN:
                return "boolean";
            case STRING:
                return "string";
            case NUMBER:
                if (data.isShort() || data.isInt() || data.isLong()) {
                    return "integer";
                }
                if (data.isFloat() || data.isDouble()) {
                    return "float";
                }
            default:
                return "unknown";
        }
    }

    private static String compareDataType(String dataType, String destType) {
        if (dataType.equalsIgnoreCase(destType)) {
            return "";
        } else {
            return "期望类型是 " + destType + "，实际类型是 " + dataType;
        }
    }
}
