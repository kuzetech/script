package com.xmfunny.funnydb.kafka;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.node.ObjectNode;

public class IngestRecord {

    private String type;
    private ObjectNode data;
    @JsonProperty("ingest_time")
    private Long ingestTime;
    private String ip;
    private String app;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public ObjectNode getData() {
        return data;
    }

    public void setData(ObjectNode data) {
        this.data = data;
    }

    public Long getIngestTime() {
        return ingestTime;
    }

    public void setIngestTime(Long ingestTime) {
        this.ingestTime = ingestTime;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getApp() {
        return app;
    }

    public void setApp(String app) {
        this.app = app;
    }
}