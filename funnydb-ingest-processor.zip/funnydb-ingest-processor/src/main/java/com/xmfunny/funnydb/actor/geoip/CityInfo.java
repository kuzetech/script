package com.xmfunny.funnydb.actor.geoip;

import com.maxmind.geoip2.model.CityResponse;
import com.maxmind.geoip2.record.City;
import com.maxmind.geoip2.record.Location;

public class CityInfo {
    private Integer geoNameID;
    private String name;
    private Double latitude;
    private Double longitude;

    public static CityInfo generateFromGeoResponse(CityResponse response, String[] preferedLocales) {
        CityInfo info = new CityInfo();
        City city = response.getCity();
        info.setGeoNameID(city.getGeoNameId());
        info.setName(GeoIPDB.getLocalizedName(city.getNames(), preferedLocales));

        Location location = response.getLocation();
        info.setLatitude(location.getLatitude());
        info.setLongitude(location.getLongitude());

        return info;
    }

    public Integer getGeoNameID() {
        return geoNameID;
    }

    public void setGeoNameID(Integer geoNameID) {
        this.geoNameID = geoNameID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }
}
