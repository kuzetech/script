package com.xmfunny.funnydb.kafka;

public class DispatcherInfo {
    private String topic;
    private String key;
    private Boolean success;

    public static DispatcherInfo createErrorDispatcherInfo(String errorTopic) {
        DispatcherInfo info = new DispatcherInfo();
        info.setTopic(errorTopic);
        info.setSuccess(false);
        return info;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }
}
