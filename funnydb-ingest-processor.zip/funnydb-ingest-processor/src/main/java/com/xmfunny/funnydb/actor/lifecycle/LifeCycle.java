package com.xmfunny.funnydb.actor.lifecycle;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.jetbrains.annotations.NotNull;

public class LifeCycle implements Comparable<LifeCycle> {
    @JsonProperty("begin_time")
    private Long beginTime;
    @JsonProperty("life_cycle_id")
    private String lifeCycleId;

    @Override
    public int compareTo(@NotNull LifeCycle o) {
        return -this.beginTime.compareTo(o.beginTime);
    }

    public Long getBeginTime() {
        return beginTime;
    }

    public void setBeginTime(Long beginTime) {
        this.beginTime = beginTime;
    }

    public String getLifeCycleId() {
        return lifeCycleId;
    }

    public void setLifeCycleId(String lifeCycleId) {
        this.lifeCycleId = lifeCycleId;
    }
}
