package com.xmfunny.funnydb.pipeline;

import java.util.Map;

public class PipelineConfig {
    private Map<String, PipelineConfigItem> appMap;

    public Map<String, PipelineConfigItem> getAppMap() {
        return appMap;
    }

    public void setAppMap(Map<String, PipelineConfigItem> appMap) {
        this.appMap = appMap;
    }
}
