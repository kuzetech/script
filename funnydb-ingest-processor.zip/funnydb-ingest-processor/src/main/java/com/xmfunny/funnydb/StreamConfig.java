package com.xmfunny.funnydb;

import org.apache.flink.api.java.utils.ParameterTool;

public class StreamConfig {
    private String jobName;

    private String geoDBDirPath;

    private String apiServerAddress;
    private Integer apiServerConnectTimeoutMS;
    private Integer apiServerMetadataBlockSecond;

    private String kafkaBootstrapServers;
    private String kafkaConsumerTopic;
    private String kafkaConsumerGroupId;
    private String kafkaErrorTopic;
    private String kafkaTransactionalIdPrefix;
    private Integer kafkaTransactionalTimeOutMS;


    public static StreamConfig generateFromParameterTool(ParameterTool parameterTool) {
        StreamConfig config = new StreamConfig();
        config.setJobName(parameterTool.get("jobName", "funnydb-ingest-flink-processor"));

        config.setGeoDBDirPath(parameterTool.get("geoDBDirPath", "/Users/huangsw/code/funny/funnydb/integrations/flink-apps/funnydb-ingest-processor/geoip"));

        config.setApiServerAddress(parameterTool.get("apiServerAddress", "http://localhost:9901"));
        config.setApiServerConnectTimeoutMS(parameterTool.getInt("apiServerConnectTimeoutMS", 15000));
        config.setApiServerMetadataBlockSecond(parameterTool.getInt("apiServerMetadataBlockSecond", 5));

        config.setKafkaBootstrapServers(parameterTool.get("kafkaBootstrapServers", "kafka:9093"));
        config.setKafkaConsumerTopic(parameterTool.get("kafkaConsumerTopic", "topic"));
        config.setKafkaConsumerGroupId(parameterTool.get("kafkaConsumerGroupId", "my-group"));
        config.setKafkaErrorTopic(parameterTool.get("kafkaErrorTopic", "error"));
        config.setKafkaTransactionalIdPrefix(parameterTool.get("kafkaTransactionalIdPrefix", "funnydb-processor"));
        config.setKafkaTransactionalTimeOutMS(parameterTool.getInt("kafkaTransactionalTimeOutMS", 900000));

        return config;
    }

    public String getJobName() {
        return jobName;
    }

    public void setJobName(String jobName) {
        this.jobName = jobName;
    }

    public String getGeoDBDirPath() {
        return geoDBDirPath;
    }

    public void setGeoDBDirPath(String geoDBDirPath) {
        this.geoDBDirPath = geoDBDirPath;
    }

    public String getApiServerAddress() {
        return apiServerAddress;
    }

    public void setApiServerAddress(String apiServerAddress) {
        this.apiServerAddress = apiServerAddress;
    }

    public Integer getApiServerConnectTimeoutMS() {
        return apiServerConnectTimeoutMS;
    }

    public void setApiServerConnectTimeoutMS(Integer apiServerConnectTimeoutMS) {
        this.apiServerConnectTimeoutMS = apiServerConnectTimeoutMS;
    }

    public Integer getApiServerMetadataBlockSecond() {
        return apiServerMetadataBlockSecond;
    }

    public void setApiServerMetadataBlockSecond(Integer apiServerMetadataBlockSecond) {
        this.apiServerMetadataBlockSecond = apiServerMetadataBlockSecond;
    }

    public String getKafkaBootstrapServers() {
        return kafkaBootstrapServers;
    }

    public void setKafkaBootstrapServers(String kafkaBootstrapServers) {
        this.kafkaBootstrapServers = kafkaBootstrapServers;
    }

    public String getKafkaConsumerTopic() {
        return kafkaConsumerTopic;
    }

    public void setKafkaConsumerTopic(String kafkaConsumerTopic) {
        this.kafkaConsumerTopic = kafkaConsumerTopic;
    }

    public String getKafkaConsumerGroupId() {
        return kafkaConsumerGroupId;
    }

    public void setKafkaConsumerGroupId(String kafkaConsumerGroupId) {
        this.kafkaConsumerGroupId = kafkaConsumerGroupId;
    }

    public String getKafkaErrorTopic() {
        return kafkaErrorTopic;
    }

    public void setKafkaErrorTopic(String kafkaErrorTopic) {
        this.kafkaErrorTopic = kafkaErrorTopic;
    }

    public String getKafkaTransactionalIdPrefix() {
        return kafkaTransactionalIdPrefix;
    }

    public void setKafkaTransactionalIdPrefix(String kafkaTransactionalIdPrefix) {
        this.kafkaTransactionalIdPrefix = kafkaTransactionalIdPrefix;
    }

    public Integer getKafkaTransactionalTimeOutMS() {
        return kafkaTransactionalTimeOutMS;
    }

    public void setKafkaTransactionalTimeOutMS(Integer kafkaTransactionalTimeOutMS) {
        this.kafkaTransactionalTimeOutMS = kafkaTransactionalTimeOutMS;
    }
}
