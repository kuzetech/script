package com.xmfunny.funnydb.actor.lifecycle;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.xmfunny.funnydb.MetadataEvaluator;
import com.xmfunny.funnydb.actor.ProcessActorInterface;
import com.xmfunny.funnydb.actor.ProcessActorResult;
import com.xmfunny.funnydb.kafka.IngestRecord;
import com.xmfunny.funnydb.metadata.Processors;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class LifeCycleInjectProcessActor implements ProcessActorInterface {

    private final List<ProcessActorInterface> nextProcessors = new ArrayList<>();
    private LifeCycleInjectProcessActorConfig config;

    public static LifeCycleInjectProcessActor generateFromProcessor(Processors processor, MetadataEvaluator evaluator) throws IOException {
        LifeCycleInjectProcessActorConfig config =
                ProcessActorInterface.mapper.treeToValue(processor.getConfig(), LifeCycleInjectProcessActorConfig.class);

        Arrays.sort(config.getLifeCycles());

        LifeCycleInjectProcessActor actor = new LifeCycleInjectProcessActor();
        actor.config = config;

        if (processor.getProcessors() != null) {
            for (Processors nextProcessorItem : processor.getProcessors()) {
                actor.nextProcessors.add(ProcessActorInterface.generateFromConfig(nextProcessorItem, evaluator));
            }
        }

        return actor;
    }

    @Override
    public ProcessActorResult process(IngestRecord record) {
        ObjectNode data = record.getData();

        long eventTime;
        try {
            eventTime = data.get(config.getTimeFieldName()).asLong();
        } catch (NullPointerException e) {
            return ProcessActorResult.createFairResult(
                    "LifeCycleInjectProcessActor : Time Field not exist or wrong type : " + config.getTimeFieldName(),
                    record);
        }

        boolean hit = false;
        for (LifeCycle lifeCycle : config.getLifeCycles()) {
            if (eventTime > lifeCycle.getBeginTime()) {
                hit = true;
                data.put(config.getInjectFieldName(), lifeCycle.getLifeCycleId());
                break;
            }
        }

        if (!hit) {
            return ProcessActorResult.createFairResult(
                    "LifeCycleInjectProcessActor : no suitable lifecycle : event time is " + eventTime,
                    record);
        }

        record.setData(data);

        if (this.nextProcessors.isEmpty()) {
            return ProcessActorResult.createSuccessResult(record);
        } else {
            return this.nextProcessors.get(0).process(record);
        }
    }

}
