package com.xmfunny.funnydb.actor.geoip;

import com.maxmind.geoip2.model.CountryResponse;
import com.maxmind.geoip2.record.Continent;

public class ContinentInfo {
    private Integer geoNameID;
    private String code;
    private String name;

    public static ContinentInfo generateFromGeoResponse(CountryResponse response, String[] preferedLocales) {
        Continent c = response.getContinent();
        ContinentInfo info = new ContinentInfo();
        info.setGeoNameID(c.getGeoNameId());
        info.setCode(c.getCode());
        info.setName(GeoIPDB.getLocalizedName(c.getNames(), preferedLocales));
        return info;
    }

    public Integer getGeoNameID() {
        return geoNameID;
    }

    public void setGeoNameID(Integer geoNameID) {
        this.geoNameID = geoNameID;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
