package com.xmfunny.funnydb.actor.messagemodifier;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.xmfunny.funnydb.MetadataEvaluator;
import com.xmfunny.funnydb.actor.ProcessActorInterface;
import com.xmfunny.funnydb.actor.ProcessActorResult;
import com.xmfunny.funnydb.kafka.IngestRecord;
import com.xmfunny.funnydb.metadata.Processors;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MessageModifierProcessActor implements ProcessActorInterface {

    private final List<ProcessActorInterface> nextProcessors = new ArrayList<>();
    private MessageModifierProcessActorConfig config;

    public static MessageModifierProcessActor generateFromProcessor(Processors processor, MetadataEvaluator evaluator) throws IOException {
        MessageModifierProcessActorConfig config =
                ProcessActorInterface.mapper.treeToValue(processor.getConfig(), MessageModifierProcessActorConfig.class);

        MessageModifierProcessActor actor = new MessageModifierProcessActor();
        actor.config = config;

        if (processor.getProcessors() != null) {
            for (Processors nextProcessorItem : processor.getProcessors()) {
                actor.nextProcessors.add(ProcessActorInterface.generateFromConfig(nextProcessorItem, evaluator));
            }
        }

        return actor;
    }

    @Override
    public ProcessActorResult process(IngestRecord record) {
        ObjectNode data = record.getData();

        if (config.getRemoveProperties() != null) {
            for (String removeProperty : config.getRemoveProperties()) {
                data.remove(removeProperty);
            }
        }

        if (config.getToJson() != null) {
            for (ToJson toJson : config.getToJson()) {
                JsonNode fromNodeValue = data.get(toJson.getFrom());
                if (fromNodeValue == null) {
                    return ProcessActorResult.createFairResult(
                            "MessageModifierProcessActor : miss tojson from field : " + toJson.getFrom(),
                            record);
                }
                try {
                    String fromNodeValueString = ProcessActorInterface.mapper.writeValueAsString(fromNodeValue);
                    data.put(toJson.getTo(), fromNodeValueString);
                } catch (JsonProcessingException e) {
                    return ProcessActorResult.createFairResult(
                            "MessageModifierProcessActor : from node value marshal error: " + e.getMessage(),
                            record);
                }
            }
        }

        if (config.getSetProperties() != null) {
            for (SetProperty setProperty : config.getSetProperties()) {
                data.put(setProperty.getName(), setProperty.getValue());
            }
        }


        InsertCurrentTime insertCurrentTime = config.getInsertCurrentTime();
        if (insertCurrentTime != null && !insertCurrentTime.getField().isEmpty()) {
            switch (insertCurrentTime.getType()) {
                case "unixtime":
                    data.put(insertCurrentTime.getField(), System.currentTimeMillis() / 1000L);
                    break;
                case "unixtime_milli":
                    data.put(insertCurrentTime.getField(), System.currentTimeMillis());
                    break;
                default:
                    data.put(insertCurrentTime.getField(), System.currentTimeMillis());
            }
        }

        record.setData(data);

        if (this.nextProcessors.isEmpty()) {
            return ProcessActorResult.createSuccessResult(record);
        } else {
            return this.nextProcessors.get(0).process(record);
        }
    }


}
