package com.xmfunny.funnydb.actor.clientipinjector;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ClientIpInjectorProcessActorConfig {

    @JsonProperty("skip_if_not_empty")
    private boolean skipIfNotEmpty;
    @JsonProperty("ip_field")
    private String ipField;

    public boolean isSkipIfNotEmpty() {
        return skipIfNotEmpty;
    }

    public void setSkipIfNotEmpty(boolean skipIfNotEmpty) {
        this.skipIfNotEmpty = skipIfNotEmpty;
    }

    public String getIpField() {
        return ipField;
    }

    public void setIpField(String ipField) {
        this.ipField = ipField;
    }
}
