package com.xmfunny.funnydb.actor.validatorv2;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ValidatorDetailItem {

    public static final String CODE_COMMON_ERR = "err.common";
    public static final String CODE_EVENT_PROPERTY_TYPE_ERR = "err.event.type_wrong";
    public static final String CODE_MISS_EVENT_PROPERTY_ERR = "err.event.property_miss";
    public static final String CODE_UNDEFINED_EVENT_ERR = "err.event.undefined";
    public static final String CODE_PROPERTY_TYPE_ERR = "err.property.type_wrong";
    public static final String CODE_REQUIRED_PROPERTY_TYPE_ERR = "err.property.required.type_wrong";
    public static final String CODE_REQUIRED_PROPERTY_MISS_ERR = "err.property.required.miss";
    public static final String CODE_REQUIRED_PROPERTY_NIL_ERR = "err.property.required.nil";
    public static final String CODE_OPTIONAL_PROPERTY_TYPE_ERR = "err.property.optional.type_wrong";
    public static final String CODE_OPTIONAL_PROPERTY_MISS_ERR = "err.property.optional.miss";
    public static final String CODE_OPTIONAL_PROPERTY_NIL_ERR = "err.property.optional.nil";
    public static final String CODE_ADDITIONAL_PROPERTY_ERR = "err.property.additional";

    public static final String CODE_LIFECYCLE_NO_OBJECT_ERR = "err.lifecycle.object.parsed.err";
    public static final String CODE_LIFECYCLE_TIME_FIELD_MISS_ERR = "err.lifecycle.field.time.miss";
    public static final String CODE_LIFECYCLE_TIME_FIELD_TYPE_ERR = "err.lifecycle.field.time.type_wrong";
    public static final String CODE_LIFECYCLE_EXCEED_ERR = "err.lifecycle.exceed.err";


    private String code;
    private String message;
    @JsonProperty("property_path")
    private String propertyPath;
    private String expected;
    private String actual;
    private String event;

    public ValidatorDetailItem(String propertyPath, String message) {
        this.message = message;
        this.propertyPath = propertyPath;
    }

    public ValidatorDetailItem(String code, String propertyPath, String message) {
        this.code = code;
        this.message = message;
        this.propertyPath = propertyPath;
    }

    public ValidatorDetailItem(String propertyPath, String message, String expected, String actual) {
        this.message = message;
        this.propertyPath = propertyPath;
        this.expected = expected;
        this.actual = actual;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getPropertyPath() {
        return propertyPath;
    }

    public void setPropertyPath(String propertyPath) {
        this.propertyPath = propertyPath;
    }

    public String getExpected() {
        return expected;
    }

    public void setExpected(String expected) {
        this.expected = expected;
    }

    public String getActual() {
        return actual;
    }

    public void setActual(String actual) {
        this.actual = actual;
    }

    public String getEvent() {
        return event;
    }

    public void setEvent(String event) {
        this.event = event;
    }
}
