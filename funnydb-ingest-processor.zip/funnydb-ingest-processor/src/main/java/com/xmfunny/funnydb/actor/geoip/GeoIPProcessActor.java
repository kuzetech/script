package com.xmfunny.funnydb.actor.geoip;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.xmfunny.funnydb.MetadataEvaluator;
import com.xmfunny.funnydb.actor.ProcessActorInterface;
import com.xmfunny.funnydb.actor.ProcessActorResult;
import com.xmfunny.funnydb.kafka.IngestRecord;
import com.xmfunny.funnydb.metadata.Processors;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class GeoIPProcessActor implements ProcessActorInterface {

    private final List<ProcessActorInterface> nextProcessors = new ArrayList<>();
    private GeoIPProcessActorConfig config;

    private GeoIPDB db;

    public static GeoIPProcessActor generateFromProcessor(Processors processor, MetadataEvaluator evaluator) throws IOException {
        GeoIPProcessActorConfig config =
                ProcessActorInterface.mapper.treeToValue(processor.getConfig(), GeoIPProcessActorConfig.class);

        String[] preferedLocales = config.getPreferedLocales();
        if (preferedLocales == null || preferedLocales.length == 0) {
            config.setPreferedLocales(new String[]{"zh-CN", "en"});
        }

        GeoIPProcessActor actor = new GeoIPProcessActor();
        actor.config = config;
        actor.db = evaluator.getGeoIPDB();

        if (processor.getProcessors() != null) {
            for (Processors nextProcessorItem : processor.getProcessors()) {
                actor.nextProcessors.add(ProcessActorInterface.generateFromConfig(nextProcessorItem, evaluator));
            }
        }

        return actor;
    }

    @Override
    public ProcessActorResult process(IngestRecord record) {
        ObjectNode data = record.getData();

        JsonNode ipNode = data.get(config.getInIPField());
        if (ipNode == null) {
            return ProcessActorResult.createFairResult(
                    "GeoIPProcessActor : miss in ip field : " + config.getInIPField(),
                    record);
        }

        String clientIP = ipNode.asText();
        if (clientIP.isEmpty()) {
            return ProcessActorResult.createFairResult(
                    "GeoIPProcessActor : client ip can not be empty or wrong type : filed is " + config.getInIPField(),
                    record);
        }

        // 由于没有使用场景，暂时放弃 strip_port 功能的实现
        if (config.isStripPort()) {
        }

        if (StringUtils.isNotEmpty(config.getOut().getContinentName()) ||
                StringUtils.isNotEmpty(config.getOut().getContinentCode()) ||
                StringUtils.isNotEmpty(config.getOut().getContinentGeoNameID())) {
            ContinentInfo info = null;
            try {
                info = db.lookupContinent(clientIP, config.getPreferedLocales());
            } catch (Exception e) {
                return ProcessActorResult.createFairResult(
                        "GeoIPProcessActor : db lookupContinent error : " + e.getMessage(),
                        record);
            }
            if (StringUtils.isNotEmpty(config.getOut().getContinentName())) {
                data.put(config.getOut().getContinentName(), info.getName());
            }
            if (StringUtils.isNotEmpty(config.getOut().getContinentCode())) {
                data.put(config.getOut().getContinentCode(), info.getCode());
            }
            if (StringUtils.isNotEmpty(config.getOut().getContinentGeoNameID())) {
                data.put(config.getOut().getContinentGeoNameID(), info.getGeoNameID());
            }
        }

        if (StringUtils.isNotEmpty(config.getOut().getCountryName()) ||
                StringUtils.isNotEmpty(config.getOut().getCountryISOCode()) ||
                StringUtils.isNotEmpty(config.getOut().getCountryGeoNameID())) {
            CountryInfo info = null;
            try {
                info = db.lookupCountry(clientIP, config.getPreferedLocales());
            } catch (Exception e) {
                return ProcessActorResult.createFairResult(
                        "GeoIPProcessActor : db lookupCountry error : " + e.getMessage(),
                        record);
            }
            if (StringUtils.isNotEmpty(config.getOut().getCountryGeoNameID())) {
                data.put(config.getOut().getCountryGeoNameID(), info.getGeoNameID());
            }
            if (StringUtils.isNotEmpty(config.getOut().getCountryName())) {
                data.put(config.getOut().getCountryName(), info.getName());
            }
            if (StringUtils.isNotEmpty(config.getOut().getCountryISOCode())) {
                data.put(config.getOut().getCountryISOCode(), info.getIsoCode());
            }
        }

        if (StringUtils.isNotEmpty(config.getOut().getCityGeoNameID()) ||
                StringUtils.isNotEmpty(config.getOut().getCityName()) ||
                StringUtils.isNotEmpty(config.getOut().getCityLatitude()) ||
                StringUtils.isNotEmpty(config.getOut().getCityLongitude())) {
            CityInfo info = null;
            try {
                info = db.lookupCity(clientIP, config.getPreferedLocales());
            } catch (Exception e) {
                return ProcessActorResult.createFairResult(
                        "GeoIPProcessActor : db lookupCity error : " + e.getMessage(),
                        record);
            }
            if (StringUtils.isNotEmpty(config.getOut().getCityGeoNameID())) {
                data.put(config.getOut().getCityGeoNameID(), info.getGeoNameID());
            }
            if (StringUtils.isNotEmpty(config.getOut().getCityName())) {
                data.put(config.getOut().getCityName(), info.getName());
            }
            if (StringUtils.isNotEmpty(config.getOut().getCityLatitude())) {
                data.put(config.getOut().getCityLatitude(), info.getLatitude());
            }
            if (StringUtils.isNotEmpty(config.getOut().getCityLongitude())) {
                data.put(config.getOut().getCityLongitude(), info.getLongitude());
            }
        }

        if (StringUtils.isNotEmpty(config.getOut().getSubdivision1GeoNameID()) ||
                StringUtils.isNotEmpty(config.getOut().getSubdivision2GeoNameID()) ||
                StringUtils.isNotEmpty(config.getOut().getSubdivision1Name()) ||
                StringUtils.isNotEmpty(config.getOut().getSubdivision2Name())) {
            SubdivisionInfo info = null;
            try {
                info = db.lookupSubdivisions(clientIP, config.getPreferedLocales());
            } catch (Exception e) {
                return ProcessActorResult.createFairResult(
                        "GeoIPProcessActor : db lookupSubdivisions error : " + e.getMessage(),
                        record);
            }
            if (StringUtils.isNotEmpty(config.getOut().getSubdivision1GeoNameID())) {
                data.put(config.getOut().getSubdivision1GeoNameID(), info.getGeoNameID1());
            }
            if (StringUtils.isNotEmpty(config.getOut().getSubdivision2GeoNameID())) {
                data.put(config.getOut().getSubdivision2GeoNameID(), info.getGeoNameID2());
            }
            if (StringUtils.isNotEmpty(config.getOut().getSubdivision1Name())) {
                data.put(config.getOut().getSubdivision1Name(), info.getName1());
            }
            if (StringUtils.isNotEmpty(config.getOut().getSubdivision2Name())) {
                data.put(config.getOut().getSubdivision2Name(), info.getName2());
            }
        }

        if (StringUtils.isNotEmpty(config.getOut().getIspName())) {
            IspInfo info = null;
            try {
                info = db.lookupIsp(clientIP);
            } catch (Exception e) {
                return ProcessActorResult.createFairResult(
                        "GeoIPProcessActor : db lookupIsp error : " + e.getMessage(),
                        record);
            }
            if (StringUtils.isNotEmpty(config.getOut().getIspName())) {
                data.put(config.getOut().getIspName(), info.getName());
            }
        }

        record.setData(data);

        if (this.nextProcessors.isEmpty()) {
            return ProcessActorResult.createSuccessResult(record);
        } else {
            return this.nextProcessors.get(0).process(record);
        }

    }

}
