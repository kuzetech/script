package com.xmfunny.funnydb.actor.validatorv2;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.xmfunny.funnydb.MetadataEvaluator;
import com.xmfunny.funnydb.actor.ProcessActorInterface;
import com.xmfunny.funnydb.actor.ProcessActorResult;
import com.xmfunny.funnydb.kafka.IngestRecord;
import com.xmfunny.funnydb.metadata.Processors;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

public class SchemaValidatorV2ProcessActor implements ProcessActorInterface {

    private final List<ProcessActorInterface> nextProcessors = new ArrayList<>();
    private SchemaValidatorV2ProcessActorConfig config;

    private Function<Object, Object> projector;

    public static SchemaValidatorV2ProcessActor generateFromProcessor(Processors processor, MetadataEvaluator evaluator) throws IOException {
        SchemaValidatorV2ProcessActorConfig config =
                ProcessActorInterface.mapper.treeToValue(processor.getConfig(), SchemaValidatorV2ProcessActorConfig.class);
        SchemaValidatorV2ProcessActor actor = new SchemaValidatorV2ProcessActor();
        actor.config = config;
        actor.projector = Projector.buildProjector(config.getSchema());

        if (processor.getProcessors() != null) {
            for (Processors nextProcessorItem : processor.getProcessors()) {
                actor.nextProcessors.add(ProcessActorInterface.generateFromConfig(nextProcessorItem, evaluator));
            }
        }
        return actor;
    }

    @Override
    public ProcessActorResult process(IngestRecord record) {
        ObjectNode data = record.getData();

        ValidatorResult r = new ValidatorResult();
        Validator.validateData("", config.getSchema(), data, true, r);
        if (!r.getErrors().isEmpty()) {
            StringBuilder errorMsg = new StringBuilder();
            for (ValidatorDetailItem error : r.getErrors()) {
                errorMsg.append(error.getMessage()).append(";");
            }
            return ProcessActorResult.createFairResult(
                    "SchemaValidatorV2ProcessActor : valid error : " + errorMsg,
                    record);
        }

        for (int i = r.getDeletes().size() - 1; i >= 0; i--) {
            String deleteItem = r.getDeletes().get(i);
            Projector.deleteElementByPath(record.getData(), deleteItem);
        }

        if (!config.isKeepUnknownFields()) {
            data = (ObjectNode) projector.apply(data);
        }

        record.setData(data);

        if (this.nextProcessors.isEmpty()) {
            return ProcessActorResult.createSuccessResult(record);
        } else {
            return this.nextProcessors.get(0).process(record);
        }
    }

}
