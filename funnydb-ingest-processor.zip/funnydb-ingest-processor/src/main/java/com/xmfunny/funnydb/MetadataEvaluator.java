package com.xmfunny.funnydb;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.xmfunny.funnydb.actor.ProcessActorInterface;
import com.xmfunny.funnydb.actor.ProcessActorResult;
import com.xmfunny.funnydb.actor.geoip.GeoIPDB;
import com.xmfunny.funnydb.kafka.DispatcherInfo;
import com.xmfunny.funnydb.kafka.IngestRecord;
import com.xmfunny.funnydb.kafka.KafkaMessage;
import com.xmfunny.funnydb.metadata.Processors;
import com.xmfunny.funnydb.pipeline.PipelineConfig;
import com.xmfunny.funnydb.pipeline.PipelineConfigItem;
import org.apache.flink.api.common.state.ListState;
import org.apache.flink.api.common.state.ListStateDescriptor;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.runtime.state.FunctionInitializationContext;
import org.apache.flink.runtime.state.FunctionSnapshotContext;
import org.apache.flink.streaming.api.checkpoint.CheckpointedFunction;
import org.apache.flink.streaming.api.functions.co.BroadcastProcessFunction;
import org.apache.flink.util.Collector;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class MetadataEvaluator
        extends BroadcastProcessFunction<IngestRecord, PipelineConfig, Tuple2<DispatcherInfo, String>>
        implements CheckpointedFunction {

    private final Map<String, ProcessActorInterface> actorMap = new HashMap<>();

    private ObjectMapper mapper;
    private GeoIPDB db;

    private final String errorTopic;
    private final String geoDBDirPath;

    private ListState<PipelineConfig> ruleState;
    private PipelineConfig localPipelineConfig;

    public MetadataEvaluator(String errorTopic, String geoDBDirPath) {
        this.errorTopic = errorTopic;
        this.geoDBDirPath = geoDBDirPath;
    }

    @Override
    public void initializeState(FunctionInitializationContext context) throws Exception {
        ruleState = context.getOperatorStateStore().getListState(
                new ListStateDescriptor<>("rulesList", PipelineConfig.class));
        if (ruleState.get().iterator().hasNext()) {
            localPipelineConfig = ruleState.get().iterator().next();
            reloadRules();
        }
    }

    @Override
    public void snapshotState(FunctionSnapshotContext context) throws Exception {
        ruleState.clear();
        ruleState.add(localPipelineConfig);
    }

    @Override
    public void open(Configuration conf) {
        mapper = new ObjectMapper();
        try {
            db = new GeoIPDB(this.geoDBDirPath);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void processElement(
            IngestRecord record,
            BroadcastProcessFunction<IngestRecord, PipelineConfig, Tuple2<DispatcherInfo, String>>.ReadOnlyContext ctx,
            Collector<Tuple2<DispatcherInfo, String>> out) throws Exception {

        // 需要解决一开始启动，还没有元数据时，数据会被丢弃
        if (localPipelineConfig == null) {
            KafkaMessage msg = KafkaMessage.createFailedMessage(mapper.writeValueAsString(record), "metadata is null");
            out.collect(new Tuple2<>(DispatcherInfo.createErrorDispatcherInfo(this.errorTopic), mapper.writeValueAsString(msg)));
            return;
        }

        String appAndTypeKey = getKey(record.getApp(), record.getType());
        ProcessActorInterface topActor = actorMap.get(appAndTypeKey);

        if (topActor == null) {
            KafkaMessage msg = KafkaMessage.createFailedMessage(mapper.writeValueAsString(record), "metadata error : no suitable actor : " + appAndTypeKey);
            out.collect(new Tuple2<>(DispatcherInfo.createErrorDispatcherInfo(this.errorTopic), mapper.writeValueAsString(msg)));
            return;
        }

        ProcessActorResult actorResult = topActor.process(record);

        if (!actorResult.getResult()) {
            KafkaMessage msg = KafkaMessage.createFailedMessage(mapper.writeValueAsString(actorResult.getRecord()), actorResult.getMsg());
            out.collect(new Tuple2<>(DispatcherInfo.createErrorDispatcherInfo(this.errorTopic), mapper.writeValueAsString(msg)));
            return;
        }

        if (actorResult.getTopic() == null || actorResult.getTopic().isEmpty()) {
            KafkaMessage msg = KafkaMessage.createFailedMessage(mapper.writeValueAsString(record), "metadata error : miss kafka processor");
            out.collect(new Tuple2<>(DispatcherInfo.createErrorDispatcherInfo(this.errorTopic), mapper.writeValueAsString(msg)));
            return;
        }

        DispatcherInfo kafkaDispatcherInfo = new DispatcherInfo();
        kafkaDispatcherInfo.setSuccess(true);
        kafkaDispatcherInfo.setTopic(actorResult.getTopic());
        kafkaDispatcherInfo.setKey(actorResult.getKey());

        String valueStr;
        try {
            valueStr = mapper.writeValueAsString(actorResult.getRecord().getData());
        } catch (JsonProcessingException e) {
            KafkaMessage msg = KafkaMessage.createFailedMessage(mapper.writeValueAsString(record), e.getMessage());
            out.collect(new Tuple2<>(DispatcherInfo.createErrorDispatcherInfo(this.errorTopic), mapper.writeValueAsString(msg)));
            return;
        }

        out.collect(new Tuple2<>(kafkaDispatcherInfo, valueStr));
    }

    @Override
    public void processBroadcastElement(
            PipelineConfig rule,
            Context ctx,
            Collector<Tuple2<DispatcherInfo, String>> out) throws Exception {
        localPipelineConfig = rule;
        reloadRules();
    }

    public GeoIPDB getGeoIPDB() {
        return this.db;
    }

    private String getKey(String app, String type) {
        return app + "-" + type;
    }

    private void reloadRules() throws IOException {
        actorMap.clear();
        Map<String, PipelineConfigItem> appMap = localPipelineConfig.getAppMap();
        for (String app : appMap.keySet()) {
            Map<String, Processors> typeMap = appMap.get(app).getTypeMap();
            for (String type : typeMap.keySet()) {
                Processors topProcessors = typeMap.get(type);
                ProcessActorInterface topActor = ProcessActorInterface.generateFromConfig(topProcessors, this);
                actorMap.put(getKey(app, type), topActor);
            }
        }
    }
}
