package com.xmfunny.funnydb.actor.validatorv2;

import com.fasterxml.jackson.core.JsonPointer;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.xmfunny.funnydb.actor.ProcessActorInterface;
import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;

public class Projector {

    private static final Function<Object, Object> COPY_PROJECTOR = o -> o;

    private static final Function<TypeDecl[], Function<Object, Object>> BUILD_OBJECT_PROJECTOR = decls -> {
        Map<String, Function<Object, Object>> projectors = new HashMap<>();
        for (TypeDecl schema : decls) {
            projectors.put(schema.getName(), buildProjector(schema));
        }
        return v -> {
            ObjectNode m = (ObjectNode) v;
            ObjectNode obj = ProcessActorInterface.mapper.createObjectNode();
            Set<String> keySet = projectors.keySet();
            for (String f : keySet) {
                Function<Object, Object> p = projectors.get(f);
                JsonNode i = m.get(f);
                if (i != null) {
                    obj.set(f, (JsonNode) p.apply(i));
                }
            }
            return obj;
        };
    };


    private static final Function<TypeDecl, Function<Object, Object>> BUILD_ARRAY_PROJECT = decl -> {
        Function<Object, Object> p = buildProjector(decl);
        return o -> {
            ArrayNode vm = (ArrayNode) o;
            ArrayNode obj = ProcessActorInterface.mapper.createArrayNode();
            for (JsonNode val : vm) {
                obj.add((JsonNode) p.apply(val));
            }
            return obj;
        };
    };

    public static Function<Object, Object> buildProjector(TypeDecl decl) {
        // 根据验证规则，仅保留规则内设置的字段
        switch (decl.getType()) {
            case "object":
                return BUILD_OBJECT_PROJECTOR.apply(decl.getFields());
            case "array":
                return BUILD_ARRAY_PROJECT.apply(decl.getItems());
            default:
                return COPY_PROJECTOR;
        }
    }

    public static void deleteElementByPath(ObjectNode topNodes, String removePath) {
        String removeElementIndex = removePath.substring(removePath.lastIndexOf('/') + 1);
        JsonPointer removeElementParentJsonPointer = JsonPointer.compile(removePath.substring(0, removePath.lastIndexOf('/')));
        if (StringUtils.startsWith(removeElementIndex, "[")) {
            ArrayNode parent = (ArrayNode) topNodes.at(removeElementParentJsonPointer);
            String arrayIndex = removeElementIndex.substring(1, removeElementIndex.length() - 1);
            parent.remove(Integer.parseInt(arrayIndex));
        } else {
            ObjectNode parent = (ObjectNode) topNodes.at(removeElementParentJsonPointer);
            parent.remove(removeElementIndex);
        }
    }

}
