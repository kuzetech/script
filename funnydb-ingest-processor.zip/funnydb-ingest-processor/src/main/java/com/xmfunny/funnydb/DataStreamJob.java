/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.xmfunny.funnydb;

import com.xmfunny.funnydb.kafka.DispatcherInfo;
import com.xmfunny.funnydb.kafka.IngestRecord;
import com.xmfunny.funnydb.kafka.IngestRecordSchema;
import com.xmfunny.funnydb.kafka.KafkaRecordDispatcherSerializationSchema;
import com.xmfunny.funnydb.pipeline.PipelineConfig;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.common.state.MapStateDescriptor;
import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.connector.base.DeliveryGuarantee;
import org.apache.flink.connector.kafka.sink.KafkaSink;
import org.apache.flink.connector.kafka.source.KafkaSource;
import org.apache.flink.connector.kafka.source.enumerator.initializer.OffsetsInitializer;
import org.apache.flink.streaming.api.datastream.BroadcastStream;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DataStreamJob {

    private static final Logger log = LoggerFactory.getLogger(DataStreamJob.class);

    private static final String STATE_DESCRIPTOR_NAME = "RulesBroadcastState";

    public static void main(String[] args) throws Exception {

        log.info("启动应用");

        ParameterTool parameterTool = ParameterTool.fromArgs(args);
        log.info("传入的参数是：" + parameterTool.getProperties().toString());

        StreamConfig streamConfig = StreamConfig.generateFromParameterTool(parameterTool);

        StreamExecutionEnvironment env = StreamUtil.prepareExecutionEnv(parameterTool);

        MetadataSource metadataSource = new MetadataSource(
                streamConfig.getApiServerAddress(),
                streamConfig.getApiServerConnectTimeoutMS(),
                streamConfig.getApiServerMetadataBlockSecond());

        DataStreamSource<PipelineConfig> metadataStream =
                env.addSource(metadataSource).setParallelism(1);

        KafkaSource<IngestRecord> kafkaSource = KafkaSource.<IngestRecord>builder()
                .setBootstrapServers(streamConfig.getKafkaBootstrapServers())
                .setTopics(streamConfig.getKafkaConsumerTopic())
                .setGroupId(streamConfig.getKafkaConsumerGroupId())
                .setStartingOffsets(OffsetsInitializer.earliest())
                .setValueOnlyDeserializer(new IngestRecordSchema())
                .build();

        DataStreamSource<IngestRecord> eventSource =
                env.fromSource(kafkaSource, WatermarkStrategy.noWatermarks(), "source");

        MapStateDescriptor<Void, PipelineConfig> bcStateDescriptor =
                new MapStateDescriptor<>(STATE_DESCRIPTOR_NAME, Types.VOID, Types.POJO(PipelineConfig.class));

        BroadcastStream<PipelineConfig> bcedMetadata = metadataStream.broadcast(bcStateDescriptor);

        DataStream<Tuple2<DispatcherInfo, String>> matches = eventSource
                .connect(bcedMetadata)
                .process(new MetadataEvaluator(streamConfig.getKafkaErrorTopic(), streamConfig.getGeoDBDirPath()))
                .uid("evaluator");

        KafkaSink<Tuple2<DispatcherInfo, String>> sink = KafkaSink.<Tuple2<DispatcherInfo, String>>builder()
                .setBootstrapServers(streamConfig.getKafkaBootstrapServers())
                .setRecordSerializer(new KafkaRecordDispatcherSerializationSchema())
                .setDeliveryGuarantee(DeliveryGuarantee.EXACTLY_ONCE)
                .setTransactionalIdPrefix(streamConfig.getKafkaTransactionalIdPrefix())
                .setProperty("transaction.timeout.ms", streamConfig.getKafkaTransactionalTimeOutMS().toString())
                .build();

        matches.sinkTo(sink);

        env.execute(streamConfig.getJobName());

    }
}
