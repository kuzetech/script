package com.xmfunny.funnydb.actor.geoip;

import com.maxmind.geoip2.model.CountryResponse;
import com.maxmind.geoip2.record.Country;

public class CountryInfo {
    private Integer geoNameID;
    private String isoCode;
    private String name;

    public static CountryInfo generateFromGeoResponse(CountryResponse response, String[] preferedLocales) {
        Country c = response.getCountry();
        CountryInfo info = new CountryInfo();
        info.setGeoNameID(c.getGeoNameId());
        info.setIsoCode(c.getIsoCode());
        info.setName(GeoIPDB.getLocalizedName(c.getNames(), preferedLocales));
        return info;
    }

    public Integer getGeoNameID() {
        return geoNameID;
    }

    public void setGeoNameID(Integer geoNameID) {
        this.geoNameID = geoNameID;
    }

    public String getIsoCode() {
        return isoCode;
    }

    public void setIsoCode(String isoCode) {
        this.isoCode = isoCode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
