package com.xmfunny.funnydb.kafka;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.flink.api.common.serialization.DeserializationSchema;
import org.apache.flink.api.common.serialization.SerializationSchema;
import org.apache.flink.api.common.typeinfo.TypeInformation;

import java.io.IOException;

public class IngestRecordSchema implements DeserializationSchema<IngestRecord>, SerializationSchema<IngestRecord> {

    private static final long serialVersionUID = 1L;
    private static final ObjectMapper mapper = new ObjectMapper();

    @Override
    public byte[] serialize(IngestRecord event) {
        return event.toString().getBytes();
    }

    @Override
    public IngestRecord deserialize(byte[] message) throws IOException {
        return mapper.readValue(message, IngestRecord.class);
    }

    @Override
    public boolean isEndOfStream(IngestRecord nextElement) {
        return false;
    }

    @Override
    public TypeInformation<IngestRecord> getProducedType() {
        return TypeInformation.of(IngestRecord.class);
    }
}
