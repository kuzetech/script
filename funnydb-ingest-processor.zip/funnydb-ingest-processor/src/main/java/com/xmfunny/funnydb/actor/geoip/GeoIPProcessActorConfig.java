package com.xmfunny.funnydb.actor.geoip;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GeoIPProcessActorConfig {

    @JsonProperty("in_ip_field")
    private String inIPField;
    @JsonProperty("strip_port")
    private boolean stripPort;
    @JsonProperty("prefered_locales")
    private String[] preferedLocales;
    @JsonProperty("out")
    private GeoIPOutField out;

    public String getInIPField() {
        return inIPField;
    }

    public void setInIPField(String inIPField) {
        this.inIPField = inIPField;
    }

    public boolean isStripPort() {
        return stripPort;
    }

    public void setStripPort(boolean stripPort) {
        this.stripPort = stripPort;
    }

    public String[] getPreferedLocales() {
        return preferedLocales;
    }

    public void setPreferedLocales(String[] preferedLocales) {
        this.preferedLocales = preferedLocales;
    }

    public GeoIPOutField getOut() {
        return out;
    }

    public void setOut(GeoIPOutField out) {
        this.out = out;
    }
}
