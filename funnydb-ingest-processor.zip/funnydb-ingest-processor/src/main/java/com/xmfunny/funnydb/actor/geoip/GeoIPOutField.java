package com.xmfunny.funnydb.actor.geoip;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GeoIPOutField {
    @JsonProperty("continent_name")
    private String continentName;
    @JsonProperty("continent_code")
    private String continentCode;
    @JsonProperty("continent_geo_name_id")
    private String continentGeoNameID;
    @JsonProperty("country_name")
    private String countryName;
    @JsonProperty("country_iso")
    private String countryISOCode;
    @JsonProperty("country_geo_name_id")
    private String countryGeoNameID;
    @JsonProperty("subdivision_1_name")
    private String subdivision1Name;
    @JsonProperty("subdivision_1_geo_name_id")
    private String subdivision1GeoNameID;
    @JsonProperty("subdivision_2_name")
    private String subdivision2Name;
    @JsonProperty("subdivision_2_geo_name_id")
    private String subdivision2GeoNameID;
    @JsonProperty("city_name")
    private String cityName;
    @JsonProperty("city_geo_name_id")
    private String cityGeoNameID;
    @JsonProperty("city_latitude")
    private String cityLatitude;
    @JsonProperty("city_longitude")
    private String cityLongitude;
    @JsonProperty("isp_name")
    private String ispName;

    public String getContinentName() {
        return continentName;
    }

    public void setContinentName(String continentName) {
        this.continentName = continentName;
    }

    public String getContinentCode() {
        return continentCode;
    }

    public void setContinentCode(String continentCode) {
        this.continentCode = continentCode;
    }

    public String getContinentGeoNameID() {
        return continentGeoNameID;
    }

    public void setContinentGeoNameID(String continentGeoNameID) {
        this.continentGeoNameID = continentGeoNameID;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public String getCountryISOCode() {
        return countryISOCode;
    }

    public void setCountryISOCode(String countryISOCode) {
        this.countryISOCode = countryISOCode;
    }

    public String getCountryGeoNameID() {
        return countryGeoNameID;
    }

    public void setCountryGeoNameID(String countryGeoNameID) {
        this.countryGeoNameID = countryGeoNameID;
    }

    public String getSubdivision1Name() {
        return subdivision1Name;
    }

    public void setSubdivision1Name(String subdivision1Name) {
        this.subdivision1Name = subdivision1Name;
    }

    public String getSubdivision1GeoNameID() {
        return subdivision1GeoNameID;
    }

    public void setSubdivision1GeoNameID(String subdivision1GeoNameID) {
        this.subdivision1GeoNameID = subdivision1GeoNameID;
    }

    public String getSubdivision2Name() {
        return subdivision2Name;
    }

    public void setSubdivision2Name(String subdivision2Name) {
        this.subdivision2Name = subdivision2Name;
    }

    public String getSubdivision2GeoNameID() {
        return subdivision2GeoNameID;
    }

    public void setSubdivision2GeoNameID(String subdivision2GeoNameID) {
        this.subdivision2GeoNameID = subdivision2GeoNameID;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public String getCityGeoNameID() {
        return cityGeoNameID;
    }

    public void setCityGeoNameID(String cityGeoNameID) {
        this.cityGeoNameID = cityGeoNameID;
    }

    public String getCityLatitude() {
        return cityLatitude;
    }

    public void setCityLatitude(String cityLatitude) {
        this.cityLatitude = cityLatitude;
    }

    public String getCityLongitude() {
        return cityLongitude;
    }

    public void setCityLongitude(String cityLongitude) {
        this.cityLongitude = cityLongitude;
    }

    public String getIspName() {
        return ispName;
    }

    public void setIspName(String ispName) {
        this.ispName = ispName;
    }
}
