package com.xmfunny.funnydb.actor.validatorv2;

import com.fasterxml.jackson.annotation.JsonProperty;

public class TypeDecl {
    private String name;
    private String type;
    @JsonProperty(value = "required")
    private boolean required;
    @JsonProperty(value = "ignore_miss")
    private boolean ignoreMiss;
    private TypeDecl[] fields;
    private TypeDecl items;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public boolean isRequired() {
        return required;
    }

    public void setRequired(boolean required) {
        this.required = required;
    }

    public boolean isIgnoreMiss() {
        return ignoreMiss;
    }

    public void setIgnoreMiss(boolean ignoreMiss) {
        this.ignoreMiss = ignoreMiss;
    }

    public TypeDecl[] getFields() {
        return fields;
    }

    public void setFields(TypeDecl[] fields) {
        this.fields = fields;
    }

    public TypeDecl getItems() {
        return items;
    }

    public void setItems(TypeDecl items) {
        this.items = items;
    }
}
