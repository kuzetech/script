package com.xmfunny.funnydb.actor.messagemodifier;

import com.fasterxml.jackson.annotation.JsonProperty;

public class MessageModifierProcessActorConfig {

    @JsonProperty("remove_properties")
    private String[] removeProperties;
    @JsonProperty("to_json")
    private ToJson[] toJson;
    @JsonProperty("set_properties")
    private SetProperty[] setProperties;
    @JsonProperty("insert_current_time")
    private InsertCurrentTime insertCurrentTime;

    public String[] getRemoveProperties() {
        return removeProperties;
    }

    public void setRemoveProperties(String[] removeProperties) {
        this.removeProperties = removeProperties;
    }

    public ToJson[] getToJson() {
        return toJson;
    }

    public void setToJson(ToJson[] toJson) {
        this.toJson = toJson;
    }

    public SetProperty[] getSetProperties() {
        return setProperties;
    }

    public void setSetProperties(SetProperty[] setProperties) {
        this.setProperties = setProperties;
    }

    public InsertCurrentTime getInsertCurrentTime() {
        return insertCurrentTime;
    }

    public void setInsertCurrentTime(InsertCurrentTime insertCurrentTime) {
        this.insertCurrentTime = insertCurrentTime;
    }
}
