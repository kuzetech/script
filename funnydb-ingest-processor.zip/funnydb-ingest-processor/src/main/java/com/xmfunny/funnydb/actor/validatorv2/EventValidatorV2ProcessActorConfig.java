package com.xmfunny.funnydb.actor.validatorv2;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Map;

@JsonIgnoreProperties({"validate_log", "validate_stats"})
public class EventValidatorV2ProcessActorConfig {

    @JsonProperty("event_property")
    private String eventProperty;
    private Map<String, EventConfig> events;

    public String getEventProperty() {
        return eventProperty;
    }

    public void setEventProperty(String eventProperty) {
        this.eventProperty = eventProperty;
    }

    public Map<String, EventConfig> getEvents() {
        return events;
    }

    public void setEvents(Map<String, EventConfig> events) {
        this.events = events;
    }
}
