package com.xmfunny.funnydb.actor.geoip;

import com.maxmind.geoip2.model.CityResponse;
import com.maxmind.geoip2.record.Subdivision;

import java.util.List;

public class SubdivisionInfo {
    private Integer geoNameID1;
    private String name1;
    private Integer geoNameID2;
    private String name2;

    public static SubdivisionInfo generateFromGeoResponse(CityResponse response, String[] preferedLocales) {
        SubdivisionInfo info = new SubdivisionInfo();
        List<Subdivision> subdivisions = response.getSubdivisions();
        if (subdivisions.size() == 1) {
            Subdivision subdivision = subdivisions.get(0);
            info.setGeoNameID1(subdivision.getGeoNameId());
            info.setName1(GeoIPDB.getLocalizedName(subdivision.getNames(), preferedLocales));
        } else if (subdivisions.size() == 2) {
            Subdivision subdivision1 = subdivisions.get(0);
            info.setGeoNameID1(subdivision1.getGeoNameId());
            info.setName1(GeoIPDB.getLocalizedName(subdivision1.getNames(), preferedLocales));
            Subdivision subdivision2 = subdivisions.get(1);
            info.setGeoNameID2(subdivision2.getGeoNameId());
            info.setName2(GeoIPDB.getLocalizedName(subdivision2.getNames(), preferedLocales));
        }
        return info;
    }

    public Integer getGeoNameID1() {
        return geoNameID1;
    }

    public void setGeoNameID1(Integer geoNameID1) {
        this.geoNameID1 = geoNameID1;
    }

    public String getName1() {
        return name1;
    }

    public void setName1(String name1) {
        this.name1 = name1;
    }

    public Integer getGeoNameID2() {
        return geoNameID2;
    }

    public void setGeoNameID2(Integer geoNameID2) {
        this.geoNameID2 = geoNameID2;
    }

    public String getName2() {
        return name2;
    }

    public void setName2(String name2) {
        this.name2 = name2;
    }
}
