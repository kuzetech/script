package com.xmfunny.funnydb;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import com.xmfunny.funnydb.metadata.*;
import com.xmfunny.funnydb.pipeline.PipelineConfig;
import com.xmfunny.funnydb.pipeline.PipelineConfigItem;
import okhttp3.*;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.source.RichSourceFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class MetadataSource extends RichSourceFunction<PipelineConfig> {

    private static final Logger log = LoggerFactory.getLogger(DataStreamJob.class);

    private static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");

    private boolean isRunning = true;

    private ObjectMapper mapper;
    private OkHttpClient client;
    private Integer instanceId;
    private Integer metadataId;

    private final String serverAddress;
    private final Integer connectTimeoutMS;
    private final Integer requestBlockSecond;

    public MetadataSource(String serverAddress, Integer connectTimeoutMS, Integer requestBlockSecond) {
        this.serverAddress = serverAddress;
        this.connectTimeoutMS = connectTimeoutMS;
        this.requestBlockSecond = requestBlockSecond;
    }

    @Override
    public void open(Configuration parameters) throws Exception {
        mapper = new ObjectMapper();
        client = new OkHttpClient.Builder()
                .connectTimeout(this.connectTimeoutMS, TimeUnit.MILLISECONDS)
                .build();
        instanceId = ensureRegistered();
        metadataId = 0;
        super.open(parameters);
    }

    @Override
    public void run(SourceContext<PipelineConfig> ctx) throws Exception {
        while (isRunning) {
            MetaData[] metadataArray;
            // 后续使用异步io优化
            if (metadataId == 0) {
                metadataArray = getMetadata(0);
            } else {
                metadataArray = getMetadata(this.requestBlockSecond);
            }
            if (metadataArray != null) {
                PipelineConfig pipelineConfig = new PipelineConfig();
                Map<String, PipelineConfigItem> appMap = new HashMap<>();
                for (MetaData metaData : metadataArray) {
                    Map<String, Processors> typeMap = new HashMap<>();
                    for (ProcessorMessages message : metaData.getMessages()) {
                        typeMap.put(message.getType(), message.getProcessors()[0]);
                    }
                    PipelineConfigItem item = new PipelineConfigItem();
                    item.setTypeMap(typeMap);
                    appMap.put(metaData.getName(), item);
                }
                pipelineConfig.setAppMap(appMap);
                ctx.collect(pipelineConfig);
            }
        }
    }

    private MetaData[] getMetadata(Integer timeout) throws Exception {
        MetadataSyncRequest syncRequest = new MetadataSyncRequest(this.instanceId, this.metadataId, timeout);
        String jsonContent = mapper.writeValueAsString(syncRequest);
        RequestBody body = RequestBody.create(jsonContent, JSON);
        Request request = new Request.Builder()
                .post(body)
                .url(this.serverAddress + "/internal/v1/ingest-metadata-sync/latest-metadata")
                .build();
        Call call = client.newCall(request);
        Response result = call.execute();
        if (result.isSuccessful()) {
            assert result.body() != null;
            String bodyString = result.body().string();
            if (bodyString.isEmpty()) {
                return null;
            }

            MetadataSyncResponse response = mapper.readValue(bodyString, MetadataSyncResponse.class);
            metadataId = response.getId();

            ObjectReader arrayReader = mapper.readerForArrayOf(MetaData.class);
            MetaData[] array = arrayReader.readValue(response.getContent());

            log.info("检测到元数据发生变更");

            result.body().close();
            return array;
        } else {
            throw new Exception("metadata search error");
        }
    }

    @Override
    public void cancel() {
        isRunning = false;
    }

    private Integer ensureRegistered() throws Exception {
        RequestBody body = RequestBody.create("", JSON);
        Request request = new Request.Builder()
                .post(body)
                .url(this.serverAddress + "/internal/v1/ingest-metadata-sync/register")
                .build();
        Call call = client.newCall(request);
        Response response = call.execute();
        if (response.isSuccessful()) {
            assert response.body() != null;
            String bodyString = response.body().string();
            JsonNode jsonNode = mapper.readTree(bodyString);
            Integer instanceId = jsonNode.get("id").asInt();
            log.debug("获取元数据，首先获取 instanceID - " + instanceId);
            response.body().close();
            return instanceId;
        } else {
            throw new Exception("metadata register error");
        }
    }

    @Override
    public void close() throws Exception {
        super.close();
    }
}
