package com.xmfunny.funnydb.actor.clientipinjector;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.xmfunny.funnydb.MetadataEvaluator;
import com.xmfunny.funnydb.actor.ProcessActorInterface;
import com.xmfunny.funnydb.actor.ProcessActorResult;
import com.xmfunny.funnydb.kafka.IngestRecord;
import com.xmfunny.funnydb.metadata.Processors;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ClientIpInjectorProcessActor implements ProcessActorInterface {

    private final List<ProcessActorInterface> nextProcessors = new ArrayList<>();
    private ClientIpInjectorProcessActorConfig config;

    public static ClientIpInjectorProcessActor generateFromProcessor(Processors processor, MetadataEvaluator evaluator) throws IOException {
        ClientIpInjectorProcessActorConfig config =
                ProcessActorInterface.mapper.treeToValue(processor.getConfig(), ClientIpInjectorProcessActorConfig.class);

        ClientIpInjectorProcessActor actor = new ClientIpInjectorProcessActor();
        actor.config = config;

        if (processor.getProcessors() != null) {
            for (Processors nextProcessorItem : processor.getProcessors()) {
                actor.nextProcessors.add(ProcessActorInterface.generateFromConfig(nextProcessorItem, evaluator));
            }
        }

        return actor;
    }

    @Override
    public ProcessActorResult process(IngestRecord record) {
        ObjectNode data = record.getData();

        boolean isIpFieldNotEmpty = (data.get(config.getIpField()) != null);
        if (!config.isSkipIfNotEmpty() || !isIpFieldNotEmpty) {
            data.put(config.getIpField(), record.getIp());
        }

        record.setData(data);

        if (this.nextProcessors.isEmpty()) {
            return ProcessActorResult.createSuccessResult(record);
        } else {
            return this.nextProcessors.get(0).process(record);
        }
    }

}
