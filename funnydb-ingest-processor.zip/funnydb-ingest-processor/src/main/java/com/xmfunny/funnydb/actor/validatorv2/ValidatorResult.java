package com.xmfunny.funnydb.actor.validatorv2;

import java.util.ArrayList;
import java.util.List;

public class ValidatorResult {
    private List<ValidatorDetailItem> errors = new ArrayList<>();
    private List<ValidatorDetailItem> deleteItems = new ArrayList<>();
    private List<String> deletes = new ArrayList<>();

    public List<ValidatorDetailItem> getErrors() {
        return errors;
    }

    public void setErrors(List<ValidatorDetailItem> errors) {
        this.errors = errors;
    }

    public List<ValidatorDetailItem> getDeleteItems() {
        return deleteItems;
    }

    public void setDeleteItems(List<ValidatorDetailItem> deleteItems) {
        this.deleteItems = deleteItems;
    }

    public List<String> getDeletes() {
        return deletes;
    }

    public void setDeletes(List<String> deletes) {
        this.deletes = deletes;
    }
}
