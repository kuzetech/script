package com.xmfunny.funnydb.kafka;

public class KafkaMessage {

    private String code;
    private String data;
    private String msg;

    public KafkaMessage() {
    }

    public KafkaMessage(String code, String data, String msg) {
        this.code = code;
        this.data = data;
        this.msg = msg;
    }

    public static KafkaMessage createSuccessMessage(String data) {
        return new KafkaMessage("success", data, "");
    }

    public static KafkaMessage createFailedMessage(String data, String msg) {
        return new KafkaMessage("fair", data, msg);
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
