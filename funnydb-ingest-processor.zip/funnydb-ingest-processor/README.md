# flink-funnydb-processor

## 程序依赖

1. jdk 11
2. kafka
3. docker + docker-compose

## 快速开始

1. 执行以下命令，快速启动 kafka 集群
```
docker-compose up -d
```

2. 在本地启动 api-server 或者 port-forward 到本地的 9901 端口

3. 在 idea 中启动 flink 程序，默认将消费 kafka 集群中名为 topic1 的数据。转发规则如下：
    * 元数据转发规则如 `sausage-Event-#account_create  -->  sausage-ingest-events`
    * 现阶段先简单实现，写入 topic1 的数据为字符串类型，如果和 key 相同，就会对应写入相应的 topic 中
    * 如果匹配不上默认都写入名为 `error` 的 topic 中


4. 执行以下命令，启动 kafka 生产者
```
docker-compose exec kafka /opt/bitnami/kafka/bin/kafka-console-producer.sh --broker-list localhost:9092 --topic pass3
```

5. 内网 api-server 支持如下数据输入  
    * zhang_hao_sdk_67qzwjaa-Event-sdk_send_code = zhang_hao_sdk_67qzwjaa-ingest-events
    * dai_hao_ye_chui_szj1ssmo-Event-#app_start = dai_hao_ye_chui_szj1ssmo-ingest-events
    * zhang_hao_sdk_67qzwjaa-Event-sdk_login_result = zhang_hao_sdk_67qzwjaa-ingest-events
    * dai_hao_ye_chui_szj1ssmo-Event-#user_login = dai_hao_ye_chui_szj1ssmo-ingest-events
    * demo_l8z88zsv-Event-client_ping_histogram = demo_l8z88zsv-ingest-events
    * demo_l8z88zsv-Event-client_player_voteup = demo_l8z88zsv-ingest-events
    * zhang_hao_sdk_67qzwjaa-Event-sdk_suspend_login = zhang_hao_sdk_67qzwjaa-ingest-events
    * dai_hao_ye_chui_szj1ssmo-Event-#account_login = dai_hao_ye_chui_szj1ssmo-ingest-events
    

